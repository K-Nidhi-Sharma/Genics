# Genics
A neurological disease predictor
The objective of the project is to predict if a person has neural disease by finding any disease causing gene sequence (base pairs). Further, predict the risk of disease in the upcoming generations. 
![image](https://user-images.githubusercontent.com/119644365/205206662-8f74ffcc-60ef-4ce7-8a9e-194bd8aa21cb.png)

The problem statement is to identify the polymorphism (mutation) in PolyQ disease. The following are the steps identified for solving the mentioned problem statement:
 • Identify the target sequence and location of diseases causing genes using biomarkers (base pairs – ATCG). 
• Predict the probability that the disease-causing genes are carried on to the next generation using gene mutation concepts.
• Creation of GUI to display the risk of acquiring a set of neural diseases for an individual and the risk of the same group of diseases being carried to the next generation.
![image](https://user-images.githubusercontent.com/119644365/205206678-42ea50a1-c654-4ae9-9b5c-a91895fc5b76.png)

MODULE DESIGN OF PROPOSED SYSTEM![image](https://user-images.githubusercontent.com/119644365/205206718-e30e9cc4-73bc-4d84-9f8e-4365e7d8f7ba.png)
1. Upload the data in the valid format.
2. Identify the target sequence of diseases causing genes and their respective location. 
3. The location is identified using biomarkers.
4. Predict the probability that the disease-causing genes are carried on to the next generation using gene mutation concepts. 
5. Generate the reports and visuals for the results. 
![image](https://user-images.githubusercontent.com/119644365/205206731-c9e2280f-2ed2-4497-9d14-b09ae1117626.png)
